import Foundation

extension ScreenModel {
    func setActive(_ value: Bool) {
        guard active != value else { return }
        active = value
        if value { connect() }
        else if !creating && !stopping { invalidateStream() }
    }
    func reconnect() {
        guard canReconnect else { return }
        retryBlocked = false; connect()
    }
    func connect() {
        guard active, !creating, !stopping, !retryBlocked, let owned = session else { return }
        let previous = streamTask
        invalidateStream()
        let ticket = generation
        streamTask = Task { [weak self] in
            await previous?.value
            guard let self else { return }
            let retry = ScreenStreamRetry(sequence: response.sequence)
            while true {
                guard !Task.isCancelled, generation == ticket, active else { return }
                do {
                    try await client.events(owned.id, token: credential()) { [weak self] event in
                        guard let self, generation == ticket, !Task.isCancelled else { return }
                        retry.receive(event)
                        receiveScreenEvent(event)
                    }
                    if session == nil { return }
                    throw ScreenFailure.disconnected
                } catch {
                    guard !Task.isCancelled, generation == ticket else { return }
                    connected = false; self.error = ScreenFailure.message(error)
                    if case ScreenFailure.http(let code) = error, code == 404 || code == 410 {
                        finishSession("This screen session ended. Create a new session to pair again.")
                        return
                    }
                    guard let wait = retry.nextDelay(after: error) else {
                        retryBlocked = true; notice = "Stream paused. Reconnect or Stop."; return
                    }
                    notice = "Reconnecting to live analysis…"
                    do { try await delay(wait) }
                    catch { return }
                }
            }
        }
    }
}
