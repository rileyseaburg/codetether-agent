//! Terminal stop: abort analysis, emit `stopped`, close streams, clear text.
use crate::{events::event, runtime::Runtime};
use codetether_companion_protocol::EventKind;

impl Runtime {
    /// Idempotently stop; analysis and pending questions are discarded.
    pub(crate) fn stop(&mut self) {
        if self.stopped {
            return;
        }
        self.stopped = true;
        self.status = "stopped".into();
        if let Some((_, cancel)) = &self.active {
            cancel.cancel();
        }
        self.publish(event(EventKind::Stopped, None, Some("stopped")));
        self.viewers.clear();
        self.text.clear();
        self.previous.clear();
        self.pending = None;
        self.reply = None;
    }
}
