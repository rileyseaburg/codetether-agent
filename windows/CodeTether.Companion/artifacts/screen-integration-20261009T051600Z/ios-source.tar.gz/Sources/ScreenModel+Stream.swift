import Foundation

extension ScreenModel {
    func setActive(_ value: Bool) {
        active = value
        if value { connect() }
        else if !creating && !stopping { invalidateStream() }
    }
    func reconnect() { retryBlocked = false; invalidateStream(); connect() }
    func connect() {
        guard active, !creating, !stopping, !retryBlocked, let owned = session else { return }
        let previous = streamTask
        invalidateStream()
        let ticket = generation
        streamTask = Task { [weak self] in
            await previous?.value
            guard let self else { return }
            for attempt in 0..<5 {
                guard !Task.isCancelled, generation == ticket, active else { return }
                do {
                    try await client.events(owned.id, token: credential()) { [weak self] event in
                        guard let self, generation == ticket, !Task.isCancelled else { return }
                        receiveScreenEvent(event)
                    }
                    if session == nil { return }
                    throw ScreenFailure.disconnected
                } catch {
                    guard !Task.isCancelled, generation == ticket else { return }
                    connected = false; self.error = ScreenFailure.message(error)
                    if case ScreenFailure.http(let code) = error, code == 404 || code == 410 {
                        finishSession("This screen session ended. Create a new session to pair again.")
                        return
                    }
                    guard ScreenFailure.retryable(error), attempt < 4 else {
                        retryBlocked = true; notice = "Stream paused. Reconnect or Stop."; return
                    }
                    notice = "Reconnecting to live analysis…"
                    do { try await delay(UInt64(1 << attempt) * 1_000_000_000) }
                    catch { return }
                }
            }
        }
    }
}
