import Foundation

extension ScreenModel {
    var canAskQuestion: Bool {
        active && connected && !creating && !stopping && !retryBlocked
            && response.canRequestFrame && !questions.submitting && !questions.waitingForFrame
            && (session?.expiry ?? .distantPast) > Date()
            && client is ScreenQuestionNetworking
    }

    /// Fresh capture answered with the typed or dictated question.
    func askQuestion() { requestFrame(questions.draft, clearsDraft: true) }

    /// Fresh capture answered with the session's standing instructions.
    func captureNow() { requestFrame(prompt, clearsDraft: false) }

    /// Queues a fresh frame; explicit typing requests authorize relay keyboard delivery, not chat/tools.
    private func requestFrame(_ text: String, clearsDraft: Bool) {
        guard canAskQuestion, let owned = session,
              let requester = client as? ScreenQuestionNetworking else { return }
        let body = ScreenQuestion(question: text)
        guard ScreenInput.text(body.question) else {
            questions.error = ScreenFailure.invalidQuestion.localizedDescription; return
        }
        questions.cancel()
        questions.submitting = true
        let ticket = questions.generation
        questions.task = Task { [weak self] in
            guard let self else { return }
            defer {
                if questions.generation == ticket { questions.submitting = false; questions.task = nil }
            }
            do {
                _ = try await requester.ask(body, session: owned.id, token: credential())
                guard !Task.isCancelled, questions.generation == ticket, session?.id == owned.id else { return }
                if clearsDraft, questions.draft == body.question { questions.draft = "" }
                questions.waitingForFrame = response.status == "requested"
                questions.notice = "Waiting for a fresh screenshot from Windows…"
            } catch {
                guard !Task.isCancelled, questions.generation == ticket, session?.id == owned.id else { return }
                questions.error = ScreenFailure.message(error)
                questions.notice = "No automatic retry was sent. Check live analysis before trying again."
            }
        }
    }
}
