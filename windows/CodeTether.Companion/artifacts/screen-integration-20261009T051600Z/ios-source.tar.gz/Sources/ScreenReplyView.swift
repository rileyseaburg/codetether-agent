import SwiftUI

/// Sends one reply to Windows, which types it where the user last clicked.
struct ScreenReplyView: View {
    @ObservedObject var model: ScreenModel
    @ObservedObject var replies: ScreenReplyState

    var body: some View {
        Section("Type a reply on Windows") {
            TextEditor(text: $replies.draft)
                .frame(minHeight: 70)
                .font(.body)
                .accessibilityIdentifier("screen-reply")
            HStack {
                Text("\(replies.draft.utf16.count)/2000")
                    .font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button(replies.submitting ? "Sending…" : "Type on Windows") {
                    model.sendReply()
                }
                .buttonStyle(.borderedProminent)
                .disabled(!model.canSendReply || !ScreenTypingText.valid(replies.draft))
                .accessibilityIdentifier("screen-reply-send")
            }
            Text("Sends once for the currently focused Windows text field. Queued does not mean inserted. No automatic retry, clicking or submission.")
                .font(.caption).foregroundStyle(.secondary)
            if let notice = replies.notice { Text(notice).font(.footnote) }
            if let error = replies.error {
                Text(error).font(.footnote).foregroundStyle(.red)
            }
        }
    }
}
