import SwiftUI

/// Asks about a fresh screenshot. Text goes only to the owner relay endpoint.
struct ScreenQuestionView: View {
    @ObservedObject var model: ScreenModel
    @ObservedObject var questions: ScreenQuestionState
    @StateObject private var dictation = ScreenDictation()
    @Environment(\.scenePhase) private var phase

    var body: some View {
        Section("Ask about the current screen") {
            TextField("What should AI check on screen now?", text: $questions.draft, axis: .vertical)
                .lineLimit(2...5).disabled(questions.submitting)
                .accessibilityIdentifier("screen-question")
            HStack {
                Button {
                    Task { await dictation.toggle { questions.draft = $0 } }
                } label: {
                    Label(dictation.listening ? "Stop" : "Dictate",
                          systemImage: dictation.listening ? "mic.slash.fill" : "mic.fill")
                }.buttonStyle(.bordered).disabled(questions.submitting)
                Spacer()
                Button(questions.submitting ? "Sending…" : "Ask") {
                    dictation.stop(); model.askQuestion()
                }
                .buttonStyle(.borderedProminent)
                .disabled(!model.canAskQuestion || !ScreenInput.text(questions.draft))
                .accessibilityIdentifier("screen-ask")
            }
            Text("Requests a fresh capture. To type directly, start with ‘Type’, ‘Enter’, ‘Write’ or ‘Fill’. Your request authorizes one keyboard delivery—no extra review. Focus the intended Windows field first. No clicking, Enter or submission.")
                .font(.caption).foregroundStyle(.secondary)
            if let notice = questions.notice { Text(notice).font(.footnote) }
            if let error = questions.error ?? dictation.error {
                Text(error).font(.footnote).foregroundStyle(.red)
            }
        }
        .onChange(of: phase) { _, value in if value != .active { dictation.stop() } }
        .onDisappear { dictation.stop() }
    }
}
