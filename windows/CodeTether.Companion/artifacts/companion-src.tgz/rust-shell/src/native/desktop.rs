use super::{picker, state::State};
use codetether_companion_desktop::{check_available, validate_selection};

pub(super) fn invalidate(state: &mut State) {
    picker::refresh(state);
    state.status = "Capture OFF — desktop changed. Select a monitor locally again.";
}

pub(super) fn check(state: &mut State) {
    let available = check_available().is_ok();
    let selected = state.selected.as_ref().is_none_or(|monitor| {
        available && validate_selection(monitor).is_ok()
    });
    if state.desktop_available != available || !selected {
        picker::refresh(state);
        state.desktop_available = available;
        state.status = if available {
            "Capture OFF — desktop available. Select a monitor locally again."
        } else {
            "Capture OFF — desktop unavailable. Local selection has been cleared."
        };
    }
}
