use super::state::State;
use std::cell::{Cell, RefCell};

/// Window-owned state remains address-stable until after native destruction.
pub(super) struct Context {
    pub(super) state: RefCell<State>,
    pub(super) invalidate: Cell<bool>,
    pub(super) relayout: Cell<bool>,
    pub(super) failure: RefCell<Option<anyhow::Error>>,
}

impl Context {
    pub(super) fn new() -> Self {
        Self {
            state: RefCell::new(State::new()),
            invalidate: Cell::new(false),
            relayout: Cell::new(false),
            failure: RefCell::new(None),
        }
    }
}
