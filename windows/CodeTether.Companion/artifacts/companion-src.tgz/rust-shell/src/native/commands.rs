use super::{ids, pairing, picker, reveal, state::State};
use windows_sys::Win32::{Foundation::HWND, UI::WindowsAndMessaging::*};

pub(super) fn handle(hwnd: HWND, state: &mut State, word: usize) {
    let command = (word & 0xffff) as u16;
    let notification = ((word >> 16) & 0xffff) as u32;
    if notification == BN_CLICKED || command == ids::OPEN { state.pair_error.clear(); }
    match command {
        ids::OPEN => reveal::show(hwnd),
        ids::PICKER if notification == CBN_SELCHANGE => picker::choose(state),
        ids::REFRESH => picker::refresh(state),
        ids::PAIR => pairing::begin(hwnd, state),
        ids::START => {
            state.status = "Capture OFF — screen capture is not available yet.";
        }
        ids::PAUSE => {
            state.status = "Capture OFF — no capture session is running.";
        }
        ids::STOP => {
            state.device = None;
            picker::clear(state);
            state.status = "Capture OFF — unpaired; device credential forgotten and selection cleared.";
        }
        ids::EXIT => {
            state.shutdown();
            // SAFETY: the current thread owns the message loop.
            unsafe { PostQuitMessage(0); }
        }
        _ => {}
    }
}
