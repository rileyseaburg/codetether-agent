use super::{context::Context, desktop, layout, state::State};
use anyhow::Result;
use windows_sys::Win32::Foundation::HWND;

/// Drain flags rather than discarding safety events during a nested callback.
pub(super) fn apply(context: &Context, hwnd: HWND, state: &mut State) -> Result<()> {
    loop {
        let invalidate = context.invalidate.replace(false);
        let relayout = context.relayout.replace(false);
        if !invalidate && !relayout { break; }
        if invalidate { desktop::invalidate(state); }
        if relayout { layout::update(hwnd, state)?; }
    }
    if let Some(controls) = &state.controls { controls.set_status(&state.display()); }
    Ok(())
}
