use super::ids::*;
use windows_sys::{Win32::UI::WindowsAndMessaging::*, core::PCWSTR};

pub(super) struct Spec {
    pub(super) id: u16,
    pub(super) class: PCWSTR,
    pub(super) text: &'static str,
    pub(super) bounds: [i32; 4],
    pub(super) style: u32,
    pub(super) enabled: bool,
}

pub(super) fn specs() -> Vec<Spec> {
    let label = windows_sys::w!("STATIC");
    let button = windows_sys::w!("BUTTON");
    let edit = windows_sys::w!("EDIT");
    let combo = windows_sys::w!("COMBOBOX");
    vec![
        Spec { id: 0, class: label, text: "Screen Companion — local controls", bounds: [20, 16, 580, 24], style: 0, enabled: true },
        Spec { id: 0, class: label, text: "Pair with the code shown on your iPhone. Start stays unavailable until capture exists.", bounds: [20, 48, 580, 40], style: 0, enabled: true },
        Spec { id: 0, class: label, text: "Monitor (local selection only)", bounds: [20, 100, 400, 22], style: 0, enabled: true },
        Spec { id: PICKER, class: combo, text: "", bounds: [20, 126, 440, 180], style: CBS_DROPDOWNLIST as u32 | WS_VSCROLL | WS_TABSTOP, enabled: true },
        Spec { id: REFRESH, class: button, text: "Refresh", bounds: [472, 125, 120, 28], style: WS_TABSTOP, enabled: true },
        Spec { id: 0, class: label, text: "Pairing code", bounds: [20, 172, 120, 22], style: 0, enabled: true },
        Spec { id: CODE, class: edit, text: "", bounds: [148, 168, 312, 28], style: WS_BORDER | WS_TABSTOP | ES_UPPERCASE as u32, enabled: true },
        Spec { id: PAIR, class: button, text: "Pair", bounds: [472, 168, 120, 28], style: WS_TABSTOP, enabled: true },
        Spec { id: 0, class: label, text: "Interval (seconds)", bounds: [20, 216, 180, 22], style: 0, enabled: true },
        Spec { id: INTERVAL, class: edit, text: "30", bounds: [204, 211, 72, 28], style: WS_BORDER | ES_NUMBER as u32, enabled: false },
        Spec { id: PERIODIC, class: button, text: "Periodic", bounds: [20, 252, 150, 26], style: BS_AUTOCHECKBOX as u32, enabled: false },
        Spec { id: RIGHT_CLICK, class: button, text: "Right-click", bounds: [190, 252, 150, 26], style: BS_AUTOCHECKBOX as u32, enabled: false },
        Spec { id: DOUBLE_CLICK, class: button, text: "Double-click", bounds: [360, 252, 180, 26], style: BS_AUTOCHECKBOX as u32, enabled: false },
        Spec { id: START, class: button, text: "Start / resume", bounds: [20, 296, 132, 32], style: WS_TABSTOP, enabled: false },
        Spec { id: PAUSE, class: button, text: "Pause", bounds: [164, 296, 120, 32], style: WS_TABSTOP, enabled: true },
        Spec { id: STOP, class: button, text: "Stop / unpair", bounds: [296, 296, 144, 32], style: WS_TABSTOP, enabled: true },
        Spec { id: EXIT, class: button, text: "Exit", bounds: [452, 296, 140, 32], style: WS_TABSTOP, enabled: true },
        Spec { id: STATUS, class: label, text: "Capture OFF — relay pairing and capture are not connected.", bounds: [20, 348, 572, 60], style: 0, enabled: true },
        Spec { id: 0, class: label, text: "Closing this window hides controls to the tray; it is not Stop.", bounds: [20, 412, 572, 40], style: 0, enabled: true },
    ]
}