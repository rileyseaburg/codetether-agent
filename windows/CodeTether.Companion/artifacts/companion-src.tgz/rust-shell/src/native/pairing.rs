use super::{ids, state::State, text::wide};
use crate::relay::{self, Device};
use windows_sys::Win32::{Foundation::{HWND, LPARAM}, UI::{Input::KeyboardAndMouse::EnableWindow,
    WindowsAndMessaging::*}};

/// Result handed from the worker thread to the UI thread via `PostMessageW`.
type Outcome = Result<Device, String>;

fn read_code(edit: HWND) -> String {
    let mut buffer = [0u16; 64];
    // SAFETY: the edit control is a live child; buffer length is passed.
    let len = unsafe { GetWindowTextW(edit, buffer.as_mut_ptr(), buffer.len() as i32) };
    String::from_utf16_lossy(&buffer[..len.max(0) as usize])
}

fn clear_code(edit: HWND) {
    let empty = wide("");
    // SAFETY: the edit control is a live child; text is terminated.
    unsafe { SetWindowTextW(edit, empty.as_ptr()); }
}

fn set_busy(state: &State, busy: bool) {
    if let Some(c) = &state.controls {
        // SAFETY: both controls are live children of the main window.
        unsafe { EnableWindow(c.pair, i32::from(!busy)); EnableWindow(c.code, i32::from(!busy)); }
    }
}

/// Starts pairing on a worker thread. Pairing never starts capture.
pub(super) fn begin(hwnd: HWND, state: &mut State) {
    let Some(controls) = &state.controls else { return };
    let typed = read_code(controls.code);
    clear_code(controls.code);
    let Some(code) = relay::normalize(&typed) else {
        state.status = "Capture OFF — enter the 12-character code shown on your iPhone.";
        return;
    };
    state.device = None;
    set_busy(state, true);
    state.status = "Capture OFF — pairing with the relay…";
    let target = hwnd as usize;
    std::thread::spawn(move || {
        let outcome: Box<Outcome> = Box::new(relay::pair(&code));
        let pointer = Box::into_raw(outcome) as LPARAM;
        // SAFETY: the UI thread takes ownership of the box in `finish`; if posting
        // fails (window gone), reclaim it here so nothing leaks.
        if unsafe { PostMessageW(target as HWND, ids::PAIRED, 0, pointer) } == 0 {
            drop(unsafe { Box::from_raw(pointer as *mut Outcome) });
        }
    });
}

/// Applies a worker result on the UI thread.
pub(super) fn finish(state: &mut State, lparam: LPARAM) {
    // SAFETY: `begin` posted exactly one boxed Outcome for this message.
    let outcome = unsafe { Box::from_raw(lparam as *mut Outcome) };
    set_busy(state, false);
    match *outcome {
        Ok(device) => {
            state.device = Some(device);
            state.status = "Paired with iPhone — capture OFF. Start is not available yet.";
        }
        Err(message) => {
            state.device = None;
            state.pair_error = message;
            state.status = "Capture OFF — pairing failed. See message below and try a new code.";
        }
    }
}
