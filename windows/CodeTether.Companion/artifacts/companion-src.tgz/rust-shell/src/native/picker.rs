use super::{state::{State, OFF}, text::wide};
use anyhow::{Result, ensure};
use codetether_companion_desktop::{Monitor, validate_selection};
use windows_sys::Win32::{Foundation::HWND, UI::WindowsAndMessaging::*};

pub(super) fn clear(state: &mut State) {
    state.selected = None;
    state.monitors.clear();
    if let Some(controls) = &state.controls {
        // SAFETY: the combo box is a live child and owns copies of its strings.
        unsafe { SendMessageW(controls.picker, CB_RESETCONTENT, 0, 0); }
        let _ = append(controls.picker, "Choose a monitor locally");
        unsafe { SendMessageW(controls.picker, CB_SETCURSEL, 0, 0); }
    }
}

/// Records the locally chosen monitor after rechecking its exact geometry.
/// Index 0 is the prompt; any failure clears the choice. Never starts capture.
pub(super) fn choose(state: &mut State) {
    let Some(controls) = &state.controls else { return };
    // SAFETY: the picker is a live child combo box on this thread.
    let index = unsafe { SendMessageW(controls.picker, CB_GETCURSEL, 0, 0) };
    state.selected = None;
    state.status = OFF;
    let Some(monitor) = usize::try_from(index).ok().and_then(|i| i.checked_sub(1))
        .and_then(|i| state.monitors.get(i)).cloned() else { return };
    if validate_selection(&monitor).is_ok() {
        state.selected = Some(monitor);
        state.status = "Capture OFF — monitor selected locally. Start is not available yet.";
    } else {
        refresh(state);
    }
}

pub(super) fn refresh(state: &mut State) {
    clear(state);
    state.status = "Capture OFF — desktop unavailable. Refresh after returning to your desktop.";
    if let Ok(monitors) = codetether_companion_desktop::monitors() {
        if populate(state, &monitors).is_ok() {
            state.monitors = monitors;
            state.status = OFF;
        } else { clear(state); }
    }
}

fn populate(state: &State, monitors: &[Monitor]) -> Result<()> {
    let controls = state.controls.as_ref().ok_or_else(|| anyhow::anyhow!("Controls unavailable"))?;
    for monitor in monitors {
        let bounds = monitor.bounds();
        let primary = if monitor.is_primary() { " (primary)" } else { "" };
        append(controls.picker, &format!("{} — {}×{}{primary}", monitor.device(), bounds.width(), bounds.height()))?;
    }
    Ok(())
}

fn append(hwnd: HWND, label: &str) -> Result<()> {
    let label = wide(label);
    // SAFETY: a string-only combo box copies this terminated string during the call.
    let result = unsafe { SendMessageW(hwnd, CB_ADDSTRING, 0, label.as_ptr() as isize) };
    ensure!(result >= 0, "Cannot populate monitor picker");
    Ok(())
}
