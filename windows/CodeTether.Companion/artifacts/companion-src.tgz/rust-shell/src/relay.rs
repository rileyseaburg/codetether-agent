//! Relay HTTP client for device pairing. Runs off the UI thread.
use serde::Deserialize;
use std::time::Duration;

/// Fixed relay origin; device credentials never leave this host.
const PAIR_URL: &str = "https://server.codetether.run/companion/pair";

/// Memory-only device capability. No `Debug`, so it cannot be logged by accident.
pub(crate) struct Device {
    pub(crate) session_id: String,
    pub(crate) token: String,
}

#[derive(Deserialize)]
struct Receipt { id: String, device_token: String }

#[derive(Deserialize)]
struct Failure { error: String }

/// Normalizes user input the same way the relay does: 12 hex characters.
pub(crate) fn normalize(code: &str) -> Option<String> {
    let code: String = code.chars().filter(|c| !c.is_whitespace() && *c != '-')
        .collect::<String>().to_ascii_uppercase();
    (code.len() == 12 && code.chars().all(|c| c.is_ascii_hexdigit())).then_some(code)
}

/// Exchanges a one-use code for a session device token.
/// Errors are user-facing and never contain the code or token.
pub(crate) fn pair(code: &str) -> Result<Device, String> {
    let agent = ureq::AgentBuilder::new()
        .timeout_connect(Duration::from_secs(10))
        .timeout(Duration::from_secs(20))
        .redirects(0)
        .build();
    match agent.post(PAIR_URL).send_json(serde_json::json!({ "code": code })) {
        Ok(response) => {
            let receipt: Receipt = response.into_json()
                .map_err(|_| "The relay returned an unexpected pairing response.".to_string())?;
            Ok(Device { session_id: receipt.id, token: receipt.device_token })
        }
        Err(ureq::Error::Status(status, response)) => {
            let reason = response.into_json::<Failure>().map(|f| f.error)
                .unwrap_or_else(|_| format!("HTTP {status}"));
            Err(format!("Pairing refused: {reason}"))
        }
        Err(ureq::Error::Transport(_)) => Err("Cannot reach the relay. Check the network and try again.".into()),
    }
}
