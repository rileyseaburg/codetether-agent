//! Native Windows desktop eligibility and physical-pixel monitor discovery.
//!
//! [`monitors`] supplies immutable choices for local UI selection; retain the
//! chosen [`Monitor`] and call [`validate_selection`] immediately before capture.
//! This check is only a snapshot, not consent or a lock against desktop changes.
//! Hosts must also watch session/display changes, pause, cancel in-flight work,
//! and require local resume. No pixels, credentials, GUI, or network I/O live here.
//!
//! ```
//! use codetether_companion_desktop::Bounds;
//! let bounds = Bounds::new(-1920, 0, 0, 1080).unwrap();
//! assert!(bounds.contains(-1, 0));
//! assert!(!bounds.contains(0, 0));
//! ```
#![deny(unsafe_op_in_unsafe_fn)]

mod bounds;
mod error;
mod monitor;
mod platform;
mod selection;
pub use bounds::Bounds;
pub use error::Error;
pub use monitor::Monitor;
pub use platform::{check_available, monitors};
pub use selection::validate_selection;
