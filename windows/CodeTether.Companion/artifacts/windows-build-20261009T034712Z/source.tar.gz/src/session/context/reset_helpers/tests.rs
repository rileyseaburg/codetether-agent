//! Tests for [`reset_helpers`](super) module.

use crate::provider::{ContentPart, Message, Role};

use super::{build_reset_summary_message, latest_reset_marker_index};

fn text(role: Role, s: &str) -> Message {
    Message {
        role,
        content: vec![ContentPart::Text {
            text: s.to_string(),
        }],
    }
}

#[test]
fn reset_summary_message_carries_expected_markers() {
    let msg = build_reset_summary_message("the summary body", "\n\n[DROPPED-RANGE INDEX] toc");
    assert!(matches!(msg.role, Role::Assistant));
    if let ContentPart::Text { text } = &msg.content[0] {
        assert!(text.starts_with("[CONTEXT RESET]"));
        assert!(text.contains("the summary body"));
        assert!(text.contains("[DROPPED-RANGE INDEX]"));
        assert!(text.contains("session_recall"));
        assert!(text.contains("only when the user allows history access"));
    } else {
        panic!("expected text content");
    }
}

#[test]
fn latest_reset_marker_index_finds_text_markers() {
    let msgs = vec![
        text(Role::User, "before"),
        build_reset_summary_message("summary", ""),
        text(Role::Assistant, "after"),
    ];
    assert_eq!(latest_reset_marker_index(&msgs), Some(1));
}

#[test]
fn latest_reset_marker_index_finds_tool_result_markers() {
    let msgs = vec![Message {
        role: Role::Tool,
        content: vec![ContentPart::ToolResult {
            tool_call_id: "call-1".to_string(),
            content: "[CONTEXT RESET]\nsummary".to_string(),
        }],
    }];
    assert_eq!(latest_reset_marker_index(&msgs), Some(0));
}
